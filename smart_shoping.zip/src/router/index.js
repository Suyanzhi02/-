import Vue from 'vue'

import VueRouter from 'vue-router'
import login from '@/views/login'
import Order from '@/views/Order'
import Detail from '@/views/Detail'
import Pay from '@/views/Pay'
import Search from '@/views/Seacher'
import Layout from '@/views/Layout'
import Cart from '@/views/Layout/cart.vue'
import User from '@/views/Layout/user.vue'
import Category from '@/views/Layout/category.vue'
import Home from '@/views/Layout/home.vue'
import store from '@/store'
import SearcherList from '@/views/Seacher/SearcherList.vue'
Vue.use(VueRouter)
const router = new VueRouter({
  routes: [
    {
      path: '/',
      component: Layout,
      redirect: '/home'
    },
    { path: '/payLogin', component: login },
    { path: '/payOrder', component: Order },
    { path: '/prodetail/:id', component: Detail },
    { path: '/paypay', component: Pay },
    { path: '/search', component: Search },
    { path: '/searchlist', component: SearcherList },
    {
      path: '/PayLayout',
      component: Layout,
      children: [
        { path: '/cart', component: Cart },
        { path: '/user', component: User },
        { path: '/category', component: Category },
        { path: '/home', component: Home }
      ]
    }

  ]
})

const authUrls = ['/paypay', '/payOrder']
// next()
// next(/路径)  拦截
router.beforeEach((to, from, next) => {
  if (!authUrls.includes(to.path)) {
    next()
    return
  }
  const token = store.getters.token
  console.log(token)
  if (token) {
    next()
  } else {
    next('/PayLogin')
  }
})

export default router
