import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import '@/utils/vant-ui'
import '@/utils/storage'
import { Toast, Dialog } from 'vant'
import 'vant/lib/index.css' // 全局引入所有 Vant 样式
Vue.config.productionTip = false
Vue.use(Toast)
// Toast('嘿嘿，你好啊')
new Vue({
  router,
  store,
  Dialog,
  render: h => h(App)
}).$mount('#app')
