// 此处用于存放所有的登录请求

import request from '@/utils/request'
// 获取图形验证码的图片
export const getPicCode = () => {
  return request.get('/captcha/image')
}

// 获取图片验证码
export const codeLogin = (mobile, smsCode) => {
  return request.post('/passport/login', {
    form: {
      smsCode,
      mobile,
      isParty: false,
      partyData: {}
    }
  })
}
// 获取短信验证码
export const getMsgCode = (captchaCode, captchaKey, mobile) => {
  return request.post('/captcha/sendSmsCaptcha', {
    form: {
      captchaCode,
      captchaKey,
      mobile
    }
  })
}
