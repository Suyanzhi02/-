<template>
  <div v-if="item.goods_id" class="goods-item" @click="$router.push(`/prodetail/${item.goods_id}`)">
    <div class="left">
      <img :src="item.goods_image" alt="" />
    </div>
    <div class="right">
      <p class="tit text-ellipsis-2">
        {{ item.goods_name }}
      </p>
      <p class="count">已售 {{ item.goods_sales }} 件</p>
      <p class="price">
        <span class="new">¥{{ item.goods_price_min }}</span>
        <span class="old">¥{{ item.goods_price_max }}</span>
      </p>
    </div>
  </div>
</template>

<script>
export default {
  name: 'GoodsItem',
  props: {
    item: {
      type: Object,
      default: () => {
        return {}
      }
    }
  }
}
</script>

<style lang="less" scoped>
.goods-item {
  height: 148px;
  margin-bottom: 6px;
  padding: 10px;
  background-color: #fff;
  display: flex;
  .left {
    width: 127px;
    img {
      display: block;
      width: 100%;
    }
  }
  .right {
  flex: 1;
  // 缩小基础字体
  font-size: 13px;
  line-height: 1.2;
  padding: 8px 10px;
  display: flex;
  flex-direction: column;
  // 改为集中分布，减少垂直间距
  justify-content: flex-start;
  gap: 4px;

  .count {
    color: #999;
    // 进一步缩小销量字体
    font-size: 11px;
    // 去掉默认 margin，用 gap 控制间距
    margin: 0;
  }

  .price {
    color: #999;
    // 价格字体稍大，但比原来小
    font-size: 14px;
    margin: 0;

    .new {
      color: #f03c3c;
      margin-right: 6px;
      // 可加粗突出价格
      font-weight: bold;
    }

    .old {
      text-decoration: line-through;
      font-size: 12px;
      // 缩小原价与新价的间距
      margin-left: 4px;
    }
  }
}
}
</style>
